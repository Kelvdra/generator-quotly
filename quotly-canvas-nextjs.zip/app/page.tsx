import QuotlyCanvasGenerator from "./QuotlyCanvasGenerator";

export default function Page() {
  return <QuotlyCanvasGenerator />;
}
